<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js">
<!--<![endif]-->


<head>
	<title>Modelia</title>
	<meta charset="utf-8">
	<!--[if IE]>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<![endif]-->
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->

	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/animations.css">
	<link rel="stylesheet" href="css/font-awesome.css">
	<link rel="stylesheet" href="css/main.css" class="color-switcher-link">
	<script src="js/vendor/modernizr-custom.js"></script>

	<!--[if lt IE 9]>
		<script src="js/vendor/html5shiv.min.js"></script>
		<script src="js/vendor/respond.min.js"></script>
		<script src="js/vendor/jquery-1.12.4.min.js"></script>
	<![endif]-->

</head>

<body>
	<!--[if lt IE 9]>
		<div class="bg-danger text-center">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/" class="color-main">upgrade your browser</a> to improve your experience.</div>
	<![endif]-->

	<div class="preloader">
		<div class="preloader_image pulse"></div>
	</div>

	<!-- search modal -->
	<div class="modal" tabindex="-1" role="dialog" aria-labelledby="search_modal" id="search_modal">
		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			<span aria-hidden="true">&times;</span>
		</button>
		<div class="widget widget_search">
			<form method="get" class="searchform search-form" action="http://webdesign-finder.com/">
				<div class="form-group">
					<input type="text" value="" name="search" class="form-control" placeholder="Search keyword" id="modal-search-input">
				</div>
				<button type="submit" class=""></button>
			</form>
		</div>
	</div>

	<!-- Unyson messages modal -->
	<div class="modal fade" tabindex="-1" role="dialog" id="messages_modal">
		<div class="fw-messages-wrap ls p-normal">
			<!-- Uncomment this UL with LI to show messages in modal popup to your user: -->
			<!--
		<ul class="list-unstyled">
			<li>Message To User</li>
		</ul>
		-->

		</div>
	</div><!-- eof .modal -->

	<!-- wrappers for visual page editor and boxed version of template -->
	<div id="canvas">
		<div id="box_wrapper">

			<!-- template sections -->


			<!-- header with two Bootstrap columns - left for logo and right for navigation and includes (search, social icons, additional links and buttons etc -->
			<?php include_once 'header.php'; ?>

			<section class="page_title s-parallax bottom_mask_subtract s-overlay ds title-overlay s-py-md-25">
				<div class="container">
					<div class="row">

						<div class="fw-divider-space hidden-below-lg mt-160"></div>
						<div class="fw-divider-space hidden-above-lg mt-100"></div>

						<div class="col-md-12 text-center">
							<h1>Contact Us</h1>
							<ol class="breadcrumb">
								<li class="breadcrumb-item">
									<a href="index-2.html">Home</a>
								</li>
								<li class="breadcrumb-item">
									<a href="#">Pages</a>
								</li>
								<li class="breadcrumb-item active">
									Contact Us
								</li>
							</ol>
						</div>

						<div class="fw-divider-space hidden-below-lg mt-160"></div>
						<div class="fw-divider-space hidden-above-lg mt-100"></div>

					</div>
				</div>
			</section>

			<section class="ds">
				<section class="ds ms page_map top_mask_subtract" data-draggable="false" data-scrollwheel="false">

					<div class="marker">
						<div class="marker-address">USA, 301 S Christopher Columbus Blvd, Philadelphia, PA 19106</div>
						<div class="marker-description">
							<span>
								316 Tipple Road Philadelphia, PA 19143
							</span>
						</div>

						<img class="marker-icon" src="images/map_marker_icon.png" alt="img">
					</div>
					<!-- .marker -->

				</section>
				<section class="top_mask_add background-contact s-py-70 s-pt-md-100 s-pb-md-95 s-pt-xl-150 s-pb-xl-185 c-gutter-30">
					<div class="container">
						<div class="row">
							<div class="col-lg-5 col-xl-4 animate" data-animation="scaleAppear">
								<span class="color-main font-main fs-24 text-uppercase">modelia</span>
								<h2 class="mt-0 mb-40 text-uppercase">Contact us</h2>
								<div class="media mb-20">
									<h5 class="fs-20 mb-0 min-w-100">Phone:</h5>
									<div class="media-body ml-0 d-flex flex-column">
										<span>(800) 123-45-67</span>
										<span>(800) 123-45-68</span>
									</div>
								</div>
								<div class="media mb-20">
									<h5 class="fs-20 mb-0 min-w-100">Email:</h5>
									<div class="media-body ml-0 d-flex flex-column">
										<span>modelia@example.com</span>
									</div>
								</div>
								<div class="media mb-20">
									<h5 class="fs-20 mb-0 min-w-100">Address:</h5>
									<div class="media-body pr-lg-4 ml-0 d-flex flex-column">
										<span>316 Tipple Road Philadelphia, PA 19143</span>
									</div>
								</div>
							</div>
							<!--.col-* -->
							<div class="fw-divider-space hidden-above-lg mt-20"></div>
							<div class="col-lg-7 col-xl-8 animate" data-animation="scaleAppear">
								<form class="contact-form c-mb-20 c-gutter-20" method="post" action="http://webdesign-finder.com/">
									<div class="row">
										<div class="col-sm-6">
											<div class="form-group">
												<input type="text" name="name" class="form-control" placeholder="full name">
											</div>
										</div>
										<div class="col-sm-6">
											<div class="form-group">
												<input type="email" name="email" class="form-control" placeholder="email address">
											</div>
										</div>

									</div>
									<div class="row">
										<div class="col-sm-6">
											<div class="form-group">
												<input type="tel" name="phone" class="form-control" placeholder="phone number">
											</div>
										</div>
										<div class="col-sm-6">
											<div class="form-group">
												<input type="text" name="city" class="form-control" placeholder="your city">
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-sm-12">
											<div class="form-group">
												<textarea rows="6" cols="45" name="message" class="form-control" placeholder="your message"></textarea>
												<button type="submit" class="btn-submit"><i class="fa fa-paper-plane"></i></button>
											</div>
										</div>

									</div>
								</form>
							</div>
							<!--.col-* -->
						</div>
					</div>
				</section>
				<div class="fw-divider-space hidden-below-lg mt-50"></div>
				<div class="fw-divider-space hidden-xs hidden-above-lg mt-20"></div>
			</section>

			<footer class="page_footer ds top_mask_add s-pb-10 s-pt-70 s-pb-md-40 s-pt-md-85 s-pb-xl-140 s-pt-xl-145">
				<div class="container">
					<div class="row">
						<div class="divider-20 d-none d-xl-block"></div>

						<div class="col-12 text-center animate" data-animation="fadeInUp">

							<div class="widget widget_social_buttons">
								<a href="#" class="fa fa-facebook color-bg-icon rounded" title="facebook"></a>
								<a href="#" class="fa fa-twitter color-bg-icon rounded" title="twitter"></a>
								<a href="#" class="fa fa-google color-bg-icon rounded" title="google"></a>
							</div>

							<div class="widget logo">
								<img src="images/logo.png" alt="img">
							</div>

							<div class="widget copyright">
								<p>&copy; Copyright <span class="copyright_year">2018</span> All Rights Reserved</p>
							</div>
						</div>

					</div>
				</div>
			</footer>


		</div><!-- eof #box_wrapper -->
	</div><!-- eof #canvas -->


	<script src="js/compressed.js"></script>
	<script src="js/main.js"></script>
	<script src="js/switcher.js"></script>

	<!-- Google Map Script -->
	<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?callback=templateInitGoogleMap&amp;key=AIzaSyC0pr5xCHpaTGv12l73IExOHDJisBP2FK4"></script>

</body>


<!-- Mirrored from webdesign-finder.com/html/modelia/contact.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 28 Oct 2020 14:32:01 GMT -->
</html>